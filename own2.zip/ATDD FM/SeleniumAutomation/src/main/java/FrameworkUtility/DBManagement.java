package FrameworkUtility;

public class DBManagement {
	
	public static String[][] runQueryAndReadData()
	{
		String[][] dbData = null;
		
		//Data base code to run query and get the result set data
		
		
		return dbData;
		
	}

}
