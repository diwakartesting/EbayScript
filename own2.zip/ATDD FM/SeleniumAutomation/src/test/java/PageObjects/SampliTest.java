package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SampliTest
{
	WebDriver driver;
	public SampliTest(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="lst-ib")
	public WebElement txtSrchBox;
	
	@FindBy(name="btnK")
	public WebElement btnSearch;
	@FindBy(linkText="SIGN-ON")
	public WebElement sign;
	
	@FindBy(name="userName")
	public WebElement UserName;
	
	@FindBy(name="password")
	public WebElement Passwrd;
	
	@FindBy(name="login")
	public WebElement logIN;
	
	@FindBy(linkText="REGISTER")
	public WebElement Register;
	
	@FindBy(name="firstName")
	public WebElement FirstNam;
	
	@FindBy(name="lastName")
	public WebElement LastNam;
	
	@FindBy(name="phone")
	public WebElement Phone;
	
	@FindBy(name="userName")
	public WebElement UsrNam;
	
	@FindBy(name="address1")
	public WebElement Address;
	
	@FindBy(name="city")
	public WebElement City;
	
	@FindBy(name="state")
	public WebElement State;
	
	@FindBy(name="postalCode")
	public WebElement Postal;
	
	@FindBy(name="email")
	public WebElement Email;
	
	@FindBy(name="password")
	public WebElement Passwrdd;
	
	
	@FindBy(name="confirmPassword")
	public WebElement Cnfpwd;
	
	
	@FindBy(name="register")
	public WebElement Registr2;
}
