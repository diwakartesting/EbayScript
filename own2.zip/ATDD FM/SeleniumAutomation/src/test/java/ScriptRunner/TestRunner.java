package ScriptRunner;

import org.junit.Test;  
import org.junit.runner.RunWith;
import cucumber.api.junit.Cucumber;
import cucumber.api.CucumberOptions;

@RunWith(Cucumber.class)				
@CucumberOptions(features = "src/test/resources/Features/SampleTest.feature",
				glue = {"StepDefinitions"},
				plugin = {"pretty", "html:target/cucumber","json:target/cucumber.json","com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/report.html"}, 
				tags = {"@Sampl"},
				dryRun = false,
				
				
				monochrome = true
                
)
public class TestRunner {

	@Test
	public void testMethod() {
		
	}

}
