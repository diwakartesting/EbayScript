package StepDefinitions;

import cucumber.api.java.Before;


import java.io.IOException;

import org.openqa.selenium.TakesScreenshot;

import FrameworkUtility.FunctionLibrary;
import cucumber.api.Scenario;
import cucumber.api.java.After;

public class CucumberHooks 
{
	@Before
	public static void launchBrowser() throws IOException
	{
		//FunctionLibrary.startBrowser();
	}
	
	@After
	public static void closeBrowser(Scenario scr) throws IOException
	{
		//if(scr.isFailed())
			//FunctionLibrary.captureScreenshot(scr.getName());
		//FunctionLibrary.endBrowser();
	}
}
