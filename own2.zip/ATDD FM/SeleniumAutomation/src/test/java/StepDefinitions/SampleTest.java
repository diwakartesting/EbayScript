package StepDefinitions;

import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import FrameworkUtility.FunctionLibrary;
import PageObjects.SampliTest;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SampleTest extends FunctionLibrary
{
	

	@Given("^user is on homepage$")
    @Then("^User can able to see home page$")
    public void user_is_on_homepage()  throws Throwable {  
    	FunctionLibrary.startBrowser();
    	FunctionLibrary.launchAppURL();
    	         
    }
    
	@When("^user navigates to Login Page$")
    public void user_navigates_to_Login_Page() throws Throwable {
    	SampliTest SampliTestObj = new SampliTest(driver);
    	clickElement(SampliTestObj.sign);
    	
        
    }
    
    @Then("^user enters username and Password$")
    public void user_enters_username_and_Password() throws Throwable {
    	SampliTest SampliTestObj = new SampliTest(driver);
    	enterText(SampliTestObj.UserName, "Diwakar");
    	enterText(SampliTestObj.Passwrd, "testing@1056");
    	clickElement(SampliTestObj.logIN);
    	
    }
    
	@Then("^success message is displayed$")
    public void success_message_is_displayed() throws Throwable {

     String bodyText = driver.findElement(By.tagName("body")).getText();
     String text= ("Welcome back to Mercury Tours!");
     Assert.assertTrue("Welcome back to Mercury Tours!", bodyText.contains(text));
    	        driver.quit();  
        
    }
        
        @When("^user navigate to register page$")
        	public void user_navigate_register_page() throws Throwable {
        	SampliTest SampliTestObj = new SampliTest(driver);
        	clickElement(SampliTestObj.Register);
        	
        }
        @Then("^fill the data first name lastname$")
        public void fill_the_data_first_name_lastname() throws Throwable{
        	SampliTest SampliTestObj = new SampliTest(driver);
        	clickElement(SampliTestObj.FirstNam);
        	enterText(SampliTestObj.FirstNam, "Diwak");
        	clickElement(SampliTestObj.LastNam);
        	enterText(SampliTestObj.LastNam, "Diwa");
        	                    	
        }
        
        @Then("^able to fill all fields$")
        public void able_to_fill_all_fields(){
        	SampliTest SampliTestObj = new SampliTest(driver);
        	clickElement(SampliTestObj.Phone);
        	enterText(SampliTestObj.Phone,"701330510");
           clickElement(SampliTestObj.UserName);
           enterText(SampliTestObj.UserName, "VDiwakar609@gmail.com");
           clickElement(SampliTestObj.Address);
           enterText(SampliTestObj.Address,"Hyderabad");
           clickElement(SampliTestObj.City);
           enterText(SampliTestObj.City,"Hyderabad");
           clickElement(SampliTestObj.State);
           enterText(SampliTestObj.State,"Telangana");
           clickElement(SampliTestObj.Postal);
           enterText(SampliTestObj.Postal,"500016");
        	Select countryy =new Select(driver.findElement(By.name("country")));
        	countryy.selectByVisibleText("INDIA");
        	        	
        }
        
        
        @Then("^fill the data in fields in user information$")
        public void fill_the_data_in_fields_in_user_information(){
        	SampliTest SampliTestObj = new SampliTest(driver);
        	clickElement(SampliTestObj.Email);
            enterText(SampliTestObj.Email,"Diwakrvv");
            clickElement(SampliTestObj.Passwrdd);
            enterText(SampliTestObj.Passwrdd,"testing@1987");
            clickElement(SampliTestObj.Cnfpwd);
            enterText(SampliTestObj.Cnfpwd,"testing@1987");
        	
        	
        }
       @Then("^user click on submitbutton$")
       public void user_click_on_submitbutton(){
    	   SampliTest SampliTestObj = new SampliTest(driver);
    	   clickElement(SampliTestObj.Registr2);
           System.out.println("Register is Success");
    	  FunctionLibrary.endBrowser();
       }
    
	
	
	
	
	
	
	
	
	
}
