package StepDefinitions;

import java.util.List;

import FrameworkUtility.DBManagement;
import FrameworkUtility.FunctionLibrary;
import PageObjects.empForm;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class createEmpDetails extends FunctionLibrary 
{
	@Given("^Application should be launched on browser$")
	public void application_should_be_launched_on_browser() 
	{
	    // Write code here that turns the phrase above into concrete actions
		
		//Launch the Application URL
		FunctionLibrary.launchAppURL();
	}
	
	@Given("^Application should be up and running$")
	public void application_should_be_up_and_running() 
	{
	    // Write code here that turns the phrase above into concrete actions
		
	}

	@When("^Enter Employee Details$")
	public void enter_Employee_Details() 
	{
	    // Write code here that turns the phrase above into concrete actions
		
		//Create opbject for Employee Form page object class
		empForm empFormObj = new empForm(driver);
	    
		//Enter the person first name
		enterText(empFormObj.txtFirstName, "David");
		
		//Enter the person first name
		enterText(empFormObj.txtLastName, "John");
		
		//Select person gender
		clickElement(empFormObj.rdGenderMale);
		
		//Select Automation tool
		selectCheckBox(empFormObj.chkSeleniumWebDriver);
	}

	@Then("^Click on Submit$")
	public void click_on_Submit() 
	{
	    // Write code here that turns the phrase above into concrete actions
		
		//Create opbject for Employee Form page object class
		empForm empFormObj = new empForm(driver);
		
		//Click on submit button
		clickElement(empFormObj.btnSubmit);
	    
	}
	
	@When("^Enter Employee Details as First Name \"([^\"]*)\" and Last Name \"([^\"]*)\"$")
	public void enter_Employee_Details(String strFirstName, String strLastName) throws InterruptedException 
	{
		// Write code here that turns the phrase above into concrete actions
		
		//Create opbject for Employee Form page object class
		empForm empFormObj = new empForm(driver);

		//Enter the person first name
		enterText(empFormObj.txtFirstName, strFirstName);
		
		Thread.sleep(3000);

		//Enter the person first name
		enterText(empFormObj.txtLastName, strLastName);
		
		Thread.sleep(3000);

		//Select person gender
		clickElement(empFormObj.rdGenderMale);

		//Select Automation tool
		selectCheckBox(empFormObj.chkSeleniumWebDriver);
	}
	
	@When("^Enter Employee Information Details$")
	public void enter_Employee_Information_Details(DataTable EmpInfo) throws InterruptedException 
	{
		// Write code here that turns the phrase above into concrete actions
		// For automatic transformation, change DataTable to one of
		// List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
		// E,K,V must be a scalar (String, Integer, Date, enum etc)
		
		List<List<String>> EmpData = EmpInfo.raw();
		String strFirstName = EmpData.get(1).get(0);
		String strLastName = EmpData.get(1).get(1);
		
		//Create opbject for Employee Form page object class
		empForm empFormObj = new empForm(driver);

		//Enter the person first name
		enterText(empFormObj.txtFirstName, strFirstName);

		Thread.sleep(3000);

		//Enter the person first name
		enterText(empFormObj.txtLastName, strLastName);

		Thread.sleep(3000);

		//Select person gender
		clickElement(empFormObj.rdGenderMale);

		//Select Automation tool
		selectCheckBox(empFormObj.chkSeleniumWebDriver);
	}

}
